package exception;

public class studentexc {
	
		public static void main (String[] args)
		{
		int num=150;
		try
		{
		if(num<200)
		{
		throw new Marks("Failed Exception");
		}
		else {
		System.out.println("Student is pass");
		}
		}
		catch(Marks e)
		{
		System.out.println(e);
		}
		}



		}
		class Marks extends Exception
		{
		public Marks(String marks)
		{
		super(marks);
		}
		}


