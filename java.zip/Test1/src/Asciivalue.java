public class Asciivalue {
public static void main(String[] args)
{
for(int i = 65; i <= 90; i++)
{
System.out.println(" The ASCII value of " + (char)i + " = " + i);
}
}
}//5. Print ascii value of character from A-Z

