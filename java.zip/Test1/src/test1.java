import java.util.Scanner;

public class test1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*// int age=24;
		// String name="sanjay";
		// String j="java";
		
		//System.out.println("My Details");
		//System.out.println("My Name " +name);
		//System.out.println("I am learning " +j+ " tech");
		//System.out.println("My Age is " +age);
		
			int p = 1000;
			int r = 10;
			int t = 5;
			int interset;
			interset = (p*r*t)/100;
			System.out.println("Interset is " +interset);
			
				int b=10;
				int h=2;
				int tri= (b*h)/2;
				System.out.println("Area of Triangle is " +tri);	
				
				int br=10;
				int l=2;
				int ret= br*l;
				System.out.println("Area of Rectangle is " +ret);
				

				int a=10;
				int q=2;
				int c=10;
				int d=2;
				int e=2;
				int avg= (a+q+c+d+e)/5;
				System.out.println("Avg is " +avg);
			

				int s=10;
				int sq= s*s;
				System.out.println("Area of Square is " +sq);
				
				int rr=3;
				double cir= 2*3.14*rr;
				System.out.println("Area of circle is " +cir);*/
		Scanner sc=new Scanner (System.in) ;
		System.out.println("Enter a call");
		int n=sc.nextInt();
		int bill=0;
		if(n<=50)
		System.out.println("no bills");
		else if(n>=51 && n<=100)
		{
		bill=(n-50)*6;
		System.out.println(bill+" bills");
		}
		else if(n>=101 && n<=150)
		{
		bill=(n-50)*8+(50*6);
		System.out.println(bill+"  bills");
		}
		else
		{
		bill=(n-150)*9+(50*8)+(50*6);
		System.out.println(bill+" bills");
		}					
	}
}
